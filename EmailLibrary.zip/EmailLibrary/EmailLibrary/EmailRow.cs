﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Data.SqlClient;

namespace EmailLibrary
{
    public class EmailRow
    {
        public string connectionString
        {
            get;
            set;
        }
        public string storedProcedureName
        {
            get;
            set;
        }
        public DataSet GetEmailRow()
        {
            DataSet ds = new DataSet();
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(storedProcedureName, con);
                command.CommandType = CommandType.StoredProcedure;

                SqlDataAdapter adapter = new SqlDataAdapter(command);
                adapter.Fill(ds);
            }
            return ds;
        }
    }
}