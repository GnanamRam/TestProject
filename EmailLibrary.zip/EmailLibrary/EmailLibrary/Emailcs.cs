﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Net.Mime;
using System.Threading;
using System.ComponentModel;

namespace EmailLibrary
{
    public class Email
    {
        public string subject { get; set; }
        public string fromEmail { get; set; }
        public string fromName { get; set; }
        public string messageBody { get; set; }
        public string smtpServer { get; set; }
        public NetworkCredential smtpCredentials { get; set; }

        static bool mailSent = false;
        private static void SendCompletedCallback(object sender, AsyncCompletedEventArgs e)
        {
            // Get the unique identifier for this asynchronous operation.
            String token = (string)e.UserState;

            if (e.Cancelled)
            {
                //Update the SP with email status as not sent
                Console.WriteLine("[{0}] Send canceled.", token);
            }
            if (e.Error != null)
            {
                Console.WriteLine("[{0}] {1}", token, e.Error.ToString());
            }
            else
            {
                //Update the SP with email status as sent
                Console.WriteLine("Message sent.");
            }
            mailSent = true;
        }

        public bool SendEmail(string toEmail, string toName)
        {
            try
            {
                MailMessage Message = new MailMessage();
                Message.IsBodyHtml = true;
                Message.To.Add(new MailAddress(toEmail, toName));
                Message.From = (new MailAddress(this.fromEmail, this.fromName));
                Message.Subject = this.subject;
                Message.Body = this.messageBody;

                SmtpClient sc = new SmtpClient();
                sc.Host = this.smtpServer;
                sc.Credentials = smtpCredentials;
                sc.EnableSsl = true;

                sc.SendCompleted += new
                SendCompletedEventHandler(SendCompletedCallback);

                // The userState can be any object that allows your callback
                // method to identify this send operation.
                // For this example, the userToken is a string constant.
                //string userState = "test message1";
                sc.SendAsync(Message, "Test");

                //sc.Send(Message);
            }
            catch (Exception ex)
            {
                return false;
            }
            return true;
        }
    }
}
